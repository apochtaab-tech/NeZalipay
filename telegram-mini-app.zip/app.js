/*
 * Мини‑приложение «Детокс Телефона»
 *
 * Это файл содержит клиентскую логику для Telegram mini app. Приложение ведёт пользователя
 * по 14‑дневному курсу цифровой диеты. Оно хранит состояние в localStorage и
 * отображает задания на каждый день. Кроме того, реализована простая система
 * начисления очков, виртуальный депозит и «SOS‑90» протокол. Код старается
 * работать как в браузере, так и внутри Telegram, адаптируя тему под тёмный
 * и светлый режим.
 */

(function () {
  const tg = window.Telegram?.WebApp;
  // Применяем тему Telegram, если приложение запущено внутри клиента
  if (tg) {
    const colorScheme = tg.colorScheme || 'light';
    document.documentElement.dataset.theme = colorScheme;
    // Подстраиваем цвета из themeParams, если доступны
    if (tg.themeParams) {
      const params = tg.themeParams;
      // Переопределяем CSS‑переменные через root style
      const root = document.documentElement;
      if (params.bg_color) root.style.setProperty('--bg-color', params.bg_color);
      if (params.text_color) root.style.setProperty('--fg-color', params.text_color);
      if (params.button_color) root.style.setProperty('--primary', params.button_color);
      if (params.hint_color) root.style.setProperty('--secondary', params.hint_color);
      if (params.secondary_bg_color) root.style.setProperty('--card-bg', params.secondary_bg_color);
    }
  }

  /**
   * Определение структуры курса. Каждый день содержит набор заданий. Тип задания
   * определяет, какие дополнительные действия нужны: например, для депозита
   * требуется ввод суммы, для SOS нужен таймер, а для квестов — выбор миссий.
   */
  const courseDays = [
    {
      id: 1,
      tasks: [
        {
          id: 'deposit',
          title: 'Договор и депозит',
          description:
            'Подпишем договор: я обещаю 5 из 7 дней выполнять задания. Если нет — 50% моего депозита уйдёт в общий призовой фонд. Нажми “Подписать” и введи сумму (500–2000 ₽).',
          type: 'deposit',
          points: 1,
        },
        {
          id: 'wallpaper1',
          title: 'Обои дня',
          description:
            'Поставь обои на блокировку: «Сегодня −60 минут экрана». После установки сделай фото — пришли сюда.',
          type: 'wallpaper',
          points: 1,
        },
        {
          id: 'pointsStore',
          title: 'Магазин очков',
          description:
            'Магазин очков активирован. За выполнение заданий ты будешь получать очки и сможешь обменивать их на призы.',
          type: 'info',
          points: 0,
        },
      ],
    },
    {
      id: 2,
      tasks: [
        {
          id: 'triggerCards',
          title: 'Триггер‑карточки',
          description:
            'Сделай 3 бумажные карточки: «Зачем я беру телефон?», «Окна связи: 11:30 и 16:30», «Срыв ≠ провал — мини‑сессия 10 мин». Положи в карман или рядом с клавиатурой. Сфотографируй и пришли.',
          type: 'photo',
          points: 1,
        },
        {
          id: 'cleanNotifications',
          title: 'Чистка уведомлений',
          description:
            'Очисти уведомления: отключи всё лишнее, оставь только самые важные приложения.',
          type: 'check',
          points: 1,
        },
      ],
    },
    {
      id: 3,
      tasks: [
        {
          id: 'appTrafficLight',
          title: 'Светофор приложений',
          description:
            'Разложи приложения на три категории: зелёные (полезные), жёлтые (осторожно) и красные (затягивают). Убери красные приложения на третий экран или в папку «Намеренно». Пришли скрин после уборки.',
          type: 'photo',
          points: 2,
        },
        {
          id: 'buttonPhone',
          title: 'Режим кнопочного телефона',
          description:
            'Включи серый фильтр, убери виджеты и оставь на главном экране только Телефон, Сообщения, Камера, Карты и Заметки. Красные приложения спрячь и установи лимиты 15–30 минут.',
          type: 'check',
          points: 1,
        },
      ],
    },
    {
      id: 4,
      tasks: [
        {
          id: 'buddy',
          title: 'Бадди 2×2×2',
          description:
            'Выбери партнёра и договорись созваниваться или писать отчёт 2 минуты утром, 2 минуты днём и 2 минуты вечером. Укажите время и нажмите кнопку «Напомнить», чтобы бот пингнул вас обоих.',
          type: 'buddy',
          points: 1,
        },
        {
          id: 'deepSessions',
          title: 'Фокус 3×25',
          description:
            'Запланируй три рабочих блока по 25 минут. После каждого делай короткий перерыв.',
          type: 'check',
          points: 1,
        },
      ],
    },
    {
      id: 5,
      tasks: [
        {
          id: 'wallpaperDiet',
          title: 'Обои диеты',
          description:
            'Замени обои на новую фразу: «Сначала дело, потом лента». Вечером верни свои старые обои.',
          type: 'wallpaper',
          points: 1,
        },
        {
          id: 'increaseLimits',
          title: 'Усиление лимитов',
          description:
            'Установи ещё более строгие лимиты на красные приложения. Сократи экранное время на 20–30%.',
          type: 'check',
          points: 1,
        },
      ],
    },
    {
      id: 6,
      tasks: [
        {
          id: 'offlineQuest4',
          title: 'Офлайн‑квест (4 часа)',
          description:
            'Выбери 4 миссии на ближайшие 4 часа: 60 минут прогулки без наушников; 30 минут чтения бумажной книги; 20 минут готовки по новому рецепту; 30 минут созвона с родными (без экрана); 20 минут растяжки/йоги; 30 минут расхламления. За каждую выполненную миссию поставь печать (эмодзи). 4 печати = +3 очка.',
          type: 'quest',
          points: 3,
        },
        {
          id: 'ladderTime',
          title: 'Лестница времени',
          description:
            'Выбери следующую ступень: 30 и 60 минут для офлайн‑окон. Планируй заранее: что ты будешь делать, где и с кем.',
          type: 'ladder',
          points: 1,
        },
      ],
    },
    {
      id: 7,
      tasks: [
        {
          id: 'referral',
          title: 'Реферальный рывок',
          description:
            'Получите персональный код и пригласите двух друзей, чтобы они присоединились к курсу. За каждого приведённого друга получите бонусные очки.',
          type: 'referral',
          points: 2,
        },
        {
          id: 'miniReward',
          title: 'Мини-награда',
          description:
            'Отпразднуй успехи первой недели. Побалуй себя чем‑то приятным (прогулка, чашка кофе, маленький подарок).',
          type: 'check',
          points: 1,
        },
      ],
    },
    {
      id: 8,
      tasks: [
        {
          id: 'communicationWindows',
          title: 'Окна связи',
          description:
            'Определи два окна связи на день (например, 11:30 и 16:30), когда будешь отвечать на сообщения и почту. Вне этих окон телефон пусть отдыхает.',
          type: 'check',
          points: 1,
        },
        {
          id: 'buddyReminders',
          title: 'Пинги бадди',
          description:
            'Настрой напоминания для бадди о созвонах. Это позволит вам поддерживать друг друга и не пропускать отчёты.',
          type: 'buddy',
          points: 1,
        },
      ],
    },
    {
      id: 9,
      tasks: [
        {
          id: 'deepWork2x50',
          title: '2×50 минут',
          description:
            'Запланируй два глубоких рабочих блока по 50 минут. Выключи уведомления и сосредоточься только на одной задаче.',
          type: 'check',
          points: 1,
        },
        {
          id: 'rewardStore10',
          title: 'Магазин очков: призы',
          description:
            'У тебя накопилось достаточно очков? За 10 очков можно получить разбор с куратором на 15 минут, электронную книгу или промокод партнёра. Выбери приз!',
          type: 'store',
          points: 0,
        },
      ],
    },
    {
      id: 10,
      tasks: [
        {
          id: 'sos90',
          title: 'Протокол Срыва-90',
          description:
            'Если утащило в ленту, нажми кнопку “SOS-90”. Следуй инструкции: Стоп → Назови импульс → Выполни 4 цикла дыхания 4-7-8. Затем 10 минут займись мини‑задачей. Отметь срыв в трекере и продолжай.',
          type: 'sos',
          points: 1,
        },
      ],
    },
    {
      id: 11,
      tasks: [
        {
          id: 'voiceReport',
          title: 'Вечерний аудио‑доклад',
          description:
            'В 21:00 запиши голосовое сообщение длиной 60 секунд: “Что сделал, что помешало, что завтра”. Прикрепи фото телефона на зарядке вне спальни.',
          type: 'voice',
          points: 1,
        },
        {
          id: 'eveningWithoutScreen',
          title: 'Вечер без экрана',
          description:
            'Откладывай телефон вечером за пределами спальни. Перед сном не используй экраны.',
          type: 'check',
          points: 1,
        },
      ],
    },
    {
      id: 12,
      tasks: [
        {
          id: 'environmentOptimization',
          title: 'Оптимизация среды',
          description:
            'Убери лишние предметы со стола, организуй рабочее место так, чтобы оно не отвлекало. За этот шаг можно получить дополнительные очки.',
          type: 'check',
          points: 2,
        },
        {
          id: 'rewardStore20',
          title: 'Магазин очков: большие призы',
          description:
            'За 20 очков доступны участие в розыгрыше таймера или фирменного мерча. Прими участие!',
          type: 'store',
          points: 0,
        },
      ],
    },
    {
      id: 13,
      tasks: [
        {
          id: 'offlineQuest6',
          title: 'Большой офлайн‑квест',
          description:
            'Организуй 6 часов офлайна. Выбери 4–6 миссий из списка и получи печати. 4 печати = +5 очков.',
          type: 'quest',
          points: 5,
        },
      ],
    },
    {
      id: 14,
      tasks: [
        {
          id: 'summary',
          title: 'Итоги и приглашения',
          description:
            'Подведи итоги курса: ответь на вопросы рефлексии, оцени результаты и пригласи друзей на следующий поток.',
          type: 'summary',
          points: 2,
        },
      ],
    },
  ];

  /**
   * Получение состояния из localStorage. Если состояние отсутствует, возвращается
   * пустой объект. В дальнейшем состояние сериализуется обратно в localStorage.
   */
  function getState() {
    try {
      const raw = localStorage.getItem('detoxState');
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  }

  /**
   * Сохранение состояния. Используем JSON.stringify с try/catch, чтобы не
   * допустить блокировки приложения при ошибке.
   */
  function saveState(state) {
    try {
      localStorage.setItem('detoxState', JSON.stringify(state));
    } catch (e) {
      console.error('Не удалось сохранить состояние', e);
    }
  }

  /**
   * Возвращает индекс текущего дня курса. Началом курса считается дата,
   * сохранённая в state.startDate. Если дата ещё не установлена, используем
   * сегодняшнюю дату и сохраняем в state.startDate. Индекс ограничен
   * границами массива courseDays.
   */
  function getCurrentDayIndex(state) {
    if (!state.startDate) return 0;
    const start = new Date(state.startDate);
    const now = new Date();
    // Игнорируем время, сравнивая только даты
    const startMid = new Date(start.getFullYear(), start.getMonth(), start.getDate());
    const nowMid = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const diffDays = Math.floor((nowMid - startMid) / (1000 * 60 * 60 * 24));
    return Math.min(Math.max(diffDays, 0), courseDays.length - 1);
  }

  /**
   * Вспомогательная функция для создания HTML элементов. Удобна для
   * динамического рендеринга.
   */
  function createElem(tag, attrs = {}, children = []) {
    const el = document.createElement(tag);
    Object.entries(attrs).forEach(([key, value]) => {
      if (key === 'className') el.className = value;
      else if (key === 'innerHTML') el.innerHTML = value;
      else if (key === 'textContent') el.textContent = value;
      else el.setAttribute(key, value);
    });
    children.forEach((child) => {
      if (child) el.appendChild(child);
    });
    return el;
  }

  /**
   * Главная функция рендеринга приложения. Вызывает соответствующие
   * подфункции для отображения задач, прогресса и состояния депозита.
   */
  function render() {
    let state = getState();
    // Если стартовая дата ещё не определена, инициализируем её текущей датой
    if (!state.startDate) {
      state.startDate = new Date().toISOString().split('T')[0];
      state.tasksCompleted = {};
      state.points = 0;
      state.deposit = { amount: null, accepted: false, returned: false };
      saveState(state);
    }

    const dayIndex = getCurrentDayIndex(state);
    const dayData = courseDays[dayIndex];
    const app = document.getElementById('app');
    app.innerHTML = '';
    // Заголовок с номером дня
    const header = createElem('div', { className: 'card' }, [
      createElem('h2', { textContent: `День ${dayData.id} / ${courseDays.length}` }),
    ]);
    app.appendChild(header);

    // Отобразить сообщение о возврате депозита после 7 дня
    if (dayIndex >= 7 && !state.deposit.returned && state.deposit.accepted) {
      // Подсчитать количество выполненных дней (где выполнено хотя бы одно задание)
      let completedDays = 0;
      for (let i = 0; i < 7; i++) {
        const dayId = courseDays[i].id;
        const tasksForDay = courseDays[i].tasks;
        const comp = state.tasksCompleted?.[dayId];
        const anyCompleted = tasksForDay.some((task) => comp && comp[task.id]);
        if (anyCompleted) completedDays++;
      }
      const resultCard = createElem('div', { className: 'card' });
      let message = '';
      if (completedDays >= 5) {
        message = `Поздравляем! Вы выполнили ${completedDays} из 7 дней первой недели. Ваш депозит (${state.deposit.amount} ₽) возвращается.`;
        // Возвращаем депозит
      } else {
        const donate = Math.floor(state.deposit.amount / 2);
        const refund = state.deposit.amount - donate;
        message = `Вы выполнили только ${completedDays} из 7 дней. 50% депозита (${donate} ₽) отправляется в призовой фонд, а оставшиеся ${refund} ₽ возвращаются вам.`;
      }
      resultCard.appendChild(createElem('p', { textContent: message }));
      app.appendChild(resultCard);
      // Отметим, что депозит возвращён
      state.deposit.returned = true;
      saveState(state);
    }

    // Карточка с информацией о депозите (только на 1‑й день, до того как пользователь подпишет договор)
    if (dayIndex === 0 && !state.deposit.accepted) {
      const depositCard = createElem('div', { className: 'card' });
      depositCard.appendChild(createElem('h2', { textContent: 'Договор с будущим собой' }));
      depositCard.appendChild(createElem('p', {
        textContent:
          'Для прохождения курса нужно внести депозит от 500 до 2000 ₽. Если вы выполните 5 из 7 дней, депозит полностью вернётся. Иначе половина депозита уйдёт в общий призовой фонд.',
      }));
      const inputGroup = createElem('div', { className: 'input-group' });
      inputGroup.appendChild(createElem('label', { textContent: 'Сумма депозита (₽)' }));
      const input = createElem('input', {
        type: 'number',
        min: '500',
        max: '2000',
        value: state.deposit.amount ?? 500,
      });
      inputGroup.appendChild(input);
      const btn = createElem('button', { textContent: 'Подписать договор' });
      btn.addEventListener('click', () => {
        const value = parseInt(input.value, 10);
        if (isNaN(value) || value < 500 || value > 2000) {
          alert('Пожалуйста, введите сумму от 500 до 2000 ₽');
          return;
        }
        state.deposit = { amount: value, accepted: true, returned: false };
        saveState(state);
        // Отправляем данные в бот (если приложение в Telegram)
        if (tg) {
          tg.sendData(JSON.stringify({ action: 'deposit', amount: value }));
          tg.HapticFeedback?.impactOccurred?.('success');
        }
        render();
      });
      inputGroup.appendChild(btn);
      depositCard.appendChild(inputGroup);
      app.appendChild(depositCard);
      return; // пока договор не подписан, не показываем остальные задания
    }

    // Перебираем задания текущего дня и рисуем их карточки
    dayData.tasks.forEach((task) => {
      const card = createElem('div', { className: 'card' });
      card.appendChild(createElem('h3', { textContent: task.title }));
      card.appendChild(createElem('p', { textContent: task.description }));
      const taskId = String(task.id);
      // Статус выполнения
      const completed = !!state.tasksCompleted?.[dayData.id]?.[taskId];
      const checkbox = createElem('input', {
        type: 'checkbox',
        checked: completed,
      });
      checkbox.addEventListener('change', (e) => {
        if (!state.tasksCompleted) state.tasksCompleted = {};
        if (!state.tasksCompleted[dayData.id]) state.tasksCompleted[dayData.id] = {};
        state.tasksCompleted[dayData.id][taskId] = e.target.checked;
        // Добавляем очки, если отмечено впервые
        if (e.target.checked && !completed) {
          state.points = (state.points || 0) + (task.points || 0);
          // Сообщаем в Telegram о завершении задания
          if (tg) {
            tg.sendData(
              JSON.stringify({
                action: 'completeTask',
                day: dayData.id,
                taskId,
                points: task.points || 0,
              }),
            );
            tg.HapticFeedback?.impactOccurred?.('light');
          }
        }
        // Если снимаем галочку, вычитаем очки
        if (!e.target.checked && completed) {
          state.points = Math.max((state.points || 0) - (task.points || 0), 0);
        }
        saveState(state);
        renderProgress(dayData, state);
      });
      // Поясняющая кнопка для заданий, где нужен дополнительный ввод
      const extraBtn = (function () {
        switch (task.type) {
          case 'buddy':
          case 'ladder':
          case 'quest':
          case 'store':
          case 'sos':
            return true;
          default:
            return false;
        }
      })();
      const actionContainer = createElem('div', { className: 'task' }, [checkbox]);
      actionContainer.appendChild(createElem('label', { className: 'task-label', textContent: '' }));
      card.insertBefore(actionContainer, card.firstChild);
      if (extraBtn) {
        const btn = createElem('button', { textContent: 'Подробнее', className: '' });
        btn.addEventListener('click', () => {
          openTaskModal(dayData, task, state);
        });
        card.appendChild(btn);
      }
      app.appendChild(card);
    });

    // Общий прогресс по заданиям дня
    renderProgress(dayData, state);

    // Отображаем текущие очки и доступ к магазину в нижней части
    const pointsCard = createElem('div', { className: 'card' });
    pointsCard.appendChild(
      createElem('p', { textContent: `Накоплено очков: ${state.points || 0}` }),
    );
    pointsCard.appendChild(
      createElem('button', { textContent: 'Открыть магазин' }, []),
    );
    pointsCard.lastChild.addEventListener('click', () => {
      openStore(state);
    });
    app.appendChild(pointsCard);
  }

  /**
   * Отображает прогресс выполнения заданий за текущий день: количество
   * выполненных и общее количество заданий. Этот элемент обновляется
   * динамически, когда пользователь ставит или снимает галочки.
   */
  function renderProgress(dayData, state) {
    let progress = document.getElementById('progress');
    if (!progress) {
      progress = createElem('div', { id: 'progress' });
      document.getElementById('app').appendChild(progress);
    }
    const completedCount = dayData.tasks.filter((task) => {
      return state.tasksCompleted?.[dayData.id]?.[String(task.id)];
    }).length;
    progress.textContent = `Выполнено ${completedCount} из ${dayData.tasks.length} заданий дня.`;
  }

  /**
   * Открывает модальное окно для заданий, требующих дополнительного ввода
   * или взаимодействия. В зависимости от типа задания выводится специальный
   * интерфейс (выбор времени для бадди, лестница времени, квесты, SOS). При
   * закрытии модального окна состояние приложения не изменяется, пока пользователь
   * явно не отметит задание выполненным.
   */
  function openTaskModal(dayData, task, state) {
    const modal = document.getElementById('modal');
    const body = document.getElementById('modal-body');
    body.innerHTML = '';
    const title = createElem('h3', { textContent: task.title });
    body.appendChild(title);
    const desc = createElem('p', { textContent: task.description });
    body.appendChild(desc);
    switch (task.type) {
      case 'buddy':
        renderBuddyContent(task, state);
        break;
      case 'ladder':
        renderLadderContent(task, state);
        break;
      case 'quest':
        renderQuestContent(task, state);
        break;
      case 'store':
        renderStoreContent(task, state);
        break;
      case 'sos':
        renderSOSContent(task, state);
        break;
      default:
        // Простое модальное окно для других типов
        break;
    }
    modal.style.display = 'flex';
    // Закрытие модального окна при клике на крестик
    document.getElementById('modal-close').onclick = () => {
      modal.style.display = 'none';
    };
  }

  /**
   * Интерфейс для выбора времени созвонов с бадди (2×2×2). Пользователь
   * указывает время в формате HH:MM для утреннего, дневного и вечернего
   * отчётов. После сохранения данные могут быть отправлены в бот.
   */
  function renderBuddyContent(task, state) {
    const container = document.getElementById('modal-body');
    const form = createElem('div');
    const morningLabel = createElem('label', { textContent: 'Время утреннего отчёта (чч:мм)' });
    const morningInput = createElem('input', { type: 'time', value: '08:05' });
    const dayLabel = createElem('label', { textContent: 'Время дневного отчёта (чч:мм)' });
    const dayInput = createElem('input', { type: 'time', value: '14:05' });
    const eveningLabel = createElem('label', { textContent: 'Время вечернего отчёта (чч:мм)' });
    const eveningInput = createElem('input', { type: 'time', value: '21:05' });
    const saveBtn = createElem('button', { textContent: 'Сохранить' });
    saveBtn.addEventListener('click', () => {
      const times = {
        morning: morningInput.value,
        day: dayInput.value,
        evening: eveningInput.value,
      };
      // Сохраняем времена в состоянии (без точки taskId, чтобы не запутаться)
      if (!state.buddyTimes) state.buddyTimes = {};
      state.buddyTimes[task.id] = times;
      saveState(state);
      // Отправить данные в бот
      if (tg) {
        tg.sendData(
          JSON.stringify({ action: 'buddyTimes', times, taskId: task.id }),
        );
        tg.HapticFeedback?.impactOccurred?.('medium');
      }
      alert('Время сохранено. Не забудьте отметить задание выполненным!');
      document.getElementById('modal').style.display = 'none';
    });
    form.appendChild(morningLabel);
    form.appendChild(morningInput);
    form.appendChild(dayLabel);
    form.appendChild(dayInput);
    form.appendChild(eveningLabel);
    form.appendChild(eveningInput);
    form.appendChild(saveBtn);
    container.appendChild(form);
  }

  /**
   * Интерфейс для выбора ступеней «Лестницы времени». Пользователь выбирает
   * одну или несколько продолжительностей офлайн‑окон. Сохранённые данные
   * отображаются в состоянии.
   */
  function renderLadderContent(task, state) {
    const container = document.getElementById('modal-body');
    const label = createElem('p', {
      textContent:
        'Выберите длительность офлайн‑окон на следующую неделю. Можно выбрать сразу несколько вариантов.',
    });
    container.appendChild(label);
    const options = [30, 60, 120, 240, 360];
    const checkboxes = options.map((minutes) => {
      const wrapper = createElem('div');
      const cb = createElem('input', { type: 'checkbox' });
      const lbl = createElem('label', {
        textContent: `${minutes} минут`,
      });
      wrapper.appendChild(cb);
      wrapper.appendChild(lbl);
      container.appendChild(wrapper);
      return { minutes, cb };
    });
    const saveBtn = createElem('button', { textContent: 'Сохранить' });
    saveBtn.addEventListener('click', () => {
      const selected = checkboxes
        .filter((c) => c.cb.checked)
        .map((c) => c.minutes);
      if (selected.length === 0) {
        alert('Выберите хотя бы одну длительность.');
        return;
      }
      if (!state.ladder) state.ladder = {};
      state.ladder[task.id] = selected;
      saveState(state);
      if (tg) {
        tg.sendData(
          JSON.stringify({ action: 'ladder', durations: selected, taskId: task.id }),
        );
        tg.HapticFeedback?.impactOccurred?.('medium');
      }
      alert('Длительность сохранена! Теперь отметьте задание выполненным.');
      document.getElementById('modal').style.display = 'none';
    });
    container.appendChild(saveBtn);
  }

  /**
   * Интерфейс для квестов (офлайн‑квест 4 или 6 часов). Пользователь отмечает,
   * какие миссии он выполнил, и получает соответствующее количество печатей
   * (эмодзи). По итогу начисляются очки, если выполнены все миссии.
   */
  function renderQuestContent(task, state) {
    const container = document.getElementById('modal-body');
    // Список миссий из описания (разделяем по точке с запятой)
    const missions = task.description
      .split(':')[1]
      .split(/\.;?\s*/)
      .map((m) => m.trim())
      .filter((m) => m.length > 0);
    const missionStates = [];
    missions.forEach((mission) => {
      const wrapper = createElem('div');
      const cb = createElem('input', { type: 'checkbox' });
      const lbl = createElem('label', { textContent: mission });
      wrapper.appendChild(cb);
      wrapper.appendChild(lbl);
      container.appendChild(wrapper);
      missionStates.push({ mission, cb });
    });
    const saveBtn = createElem('button', { textContent: 'Сохранить миссии' });
    saveBtn.addEventListener('click', () => {
      const completedMissions = missionStates
        .filter((m) => m.cb.checked)
        .map((m) => m.mission);
      if (!state.quests) state.quests = {};
      state.quests[task.id] = completedMissions;
      // Добавляем дополнительный параметр «печати»: каждая миссия — печать
      const stamps = completedMissions.length;
      // Можно начислять дополнительные очки прямо здесь, но пока оставим по основным правилам
      saveState(state);
      if (tg) {
        tg.sendData(
          JSON.stringify({ action: 'quest', missions: completedMissions, taskId: task.id }),
        );
        tg.HapticFeedback?.impactOccurred?.('medium');
      }
      alert(`Сохранено ${stamps} миссий. Поставь галочку у задания, чтобы получить очки.`);
      document.getElementById('modal').style.display = 'none';
    });
    container.appendChild(saveBtn);
  }

  /**
   * Интерфейс магазина. В зависимости от количества очков отображает доступные
   * призы. Пользователь выбирает приз, после чего очки списываются. Доступ к
   * магазину реализован через отдельную функцию openStore().
   */
  function renderStoreContent(task, state) {
    const container = document.getElementById('modal-body');
    container.appendChild(
      createElem('p', { textContent: 'Добро пожаловать в магазин призов. Выберите доступный приз.' }),
    );
    const prizes = [
      { id: 'analyzer', name: 'Разбор на 15 минут с куратором', cost: 10 },
      { id: 'ebook', name: 'Электронная книга', cost: 10 },
      { id: 'promo', name: 'Промокод партнёра', cost: 10 },
      { id: 'timer', name: 'Участие в розыгрыше таймера', cost: 20 },
      { id: 'merch', name: 'Фирменный мерч', cost: 20 },
      { id: 'nextCourse', name: 'Бесплатный вход в следующий поток', cost: 30 },
    ];
    prizes.forEach((prize) => {
      if ((state.points || 0) >= prize.cost) {
        const btn = createElem('button', { textContent: `${prize.name} — ${prize.cost} очков` });
        btn.addEventListener('click', () => {
          if ((state.points || 0) < prize.cost) {
            alert('Недостаточно очков.');
            return;
          }
          state.points -= prize.cost;
          if (!state.rewards) state.rewards = [];
          state.rewards.push(prize.name);
          saveState(state);
          if (tg) {
            tg.sendData(
              JSON.stringify({ action: 'redeem', prize: prize.id, cost: prize.cost }),
            );
            tg.HapticFeedback?.impactOccurred?.('success');
          }
          alert(`Приз «${prize.name}» успешно выбран! Оставшиеся очки: ${state.points}`);
          // После выбора перерисуем магазин
          openStore(state);
        });
        container.appendChild(btn);
      }
    });
    if ((state.points || 0) < 10) {
      container.appendChild(
        createElem('p', { textContent: 'Для получения призов накопите минимум 10 очков.' }),
      );
    }
  }

  /**
   * Реализация SOS‑90. При нажатии кнопки создаётся таймер на 90 секунд для
   * дыхания 4‑7‑8, затем запускается таймер на 10 минут для мини‑задачи. После
   * завершения обоих таймеров выводится уведомление. Если приложение запущено
   * внутри Telegram, можно отправить данные в бот.
   */
  function renderSOSContent(task, state) {
    const container = document.getElementById('modal-body');
    const instructions = createElem('p', {
      textContent:
        'Начинаем протокол Срыва‑90. Сконцентрируйтесь на дыхании: вдох на 4 счёта, задержка на 7, выдох на 8. Повторите 4 цикла. После завершения начнётся таймер на 10 минут для мини‑задачи.',
    });
    container.appendChild(instructions);
    const timerDisplay = createElem('p', { textContent: '⏳ 90:00', style: 'font-weight:bold;' });
    container.appendChild(timerDisplay);
    const startBtn = createElem('button', { textContent: 'Старт' });
    startBtn.addEventListener('click', () => {
      startBtn.disabled = true;
      let timeLeft = 90;
      const interval = setInterval(() => {
        timeLeft--;
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        timerDisplay.textContent = `⏳ ${minutes.toString().padStart(2, '0')}:${seconds
          .toString()
          .padStart(2, '0')}`;
        if (timeLeft <= 0) {
          clearInterval(interval);
          // Переходим к 10‑минутной мини‑сессии
          miniSession();
        }
      }, 1000);
    });
    container.appendChild(startBtn);
    function miniSession() {
      timerDisplay.textContent = '10‑минутная мини‑сессия запущена!';
      let timeLeft = 600;
      const interval2 = setInterval(() => {
        timeLeft--;
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        timerDisplay.textContent = `⏳ ${minutes.toString().padStart(2, '0')}:${seconds
          .toString()
          .padStart(2, '0')}`;
        if (timeLeft <= 0) {
          clearInterval(interval2);
          timerDisplay.textContent = 'Сессия завершена! Вы можете продолжать курс.';
          if (tg) {
            tg.sendData(
              JSON.stringify({ action: 'sosComplete', taskId: task.id }),
            );
            tg.HapticFeedback?.impactOccurred?.('success');
          }
        }
      }, 1000);
    }
  }

  /**
   * Открывает модальное окно магазина. Содержит отображение призов в
   * зависимости от накопленных очков. Используется для кнопки «Открыть
   * магазин» в основной ленте. Это отдельная функция, чтобы внутри
   * modals были независимые обработчики.
   */
  function openStore(state) {
    const modal = document.getElementById('modal');
    const body = document.getElementById('modal-body');
    body.innerHTML = '';
    const title = createElem('h3', { textContent: 'Магазин призов' });
    body.appendChild(title);
    // Используем фиктивный объект задания для выбора призов
    const fakeTask = { id: 'storeAll', type: 'store' };
    renderStoreContent(fakeTask, state);
    modal.style.display = 'flex';
    document.getElementById('modal-close').onclick = () => {
      modal.style.display = 'none';
      render();
    };
  }

  // Инициализируем приложение после загрузки DOM
  document.addEventListener('DOMContentLoaded', () => {
    render();
  });
})();