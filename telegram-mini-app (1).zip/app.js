(function(){
  const tg = window.Telegram?.WebApp;
  if (tg) {
    const cs = tg.colorScheme || 'dark';
    document.documentElement.dataset.theme = cs;
    const p = tg.themeParams || {};
    const root = document.documentElement;
    if (p.bg_color) root.style.setProperty('--bg-color', p.bg_color);
    if (p.text_color) root.style.setProperty('--fg-color', p.text_color);
    if (p.secondary_bg_color) root.style.setProperty('--card-bg', p.secondary_bg_color);
    if (p.button_color) root.style.setProperty('--primary', p.button_color);
    if (p.hint_color) root.style.setProperty('--secondary', p.hint_color);
    try{ tg.ready(); }catch(e){}
  }

  // === КОНТЕНТ КУРСА: 14 дней по вашему ТЗ ==============================
  const WALLPAPERS = [
    "Сегодня −60 минут экрана",
    "Зачем я беру телефон?",
    "Сначала дело, потом лента",
    "25 минут — только одна задача",
    "Лента = ловушка. Я выбираю книгу",
    "4 часа офлайна — я могу",
    "Награда — за усилия",
    "Почта и чаты — по расписанию",
    "50 минут глубоко",
    "Стоп. Заметь. Выбери",
    "Сон дороже экрана",
    "Окружение помогает",
    "6 часов офлайн — легко",
    "Я держу ритм"
  ];

  const DAYS = [
    {id:1, tasks:[
      {k:'deposit', t:'Договор + депозит', d:'Подпишем договор: 5 из 7 дней. Введи сумму (500–2000 ₽). При 4/7 — 50% в приз/донат.', type:'deposit', pts:1},
      {k:'wp1', t:'Обои дня', d:'Поставь обои: «Сегодня −60 минут экрана». Пришли фото.', type:'wallpaper', pts:1},
      {k:'store', t:'Магазин очков', d:'Старт магазина очков. Копи очки и меняй на призы.', type:'info', pts:0},
    ]},
    {id:2, tasks:[
      {k:'cards', t:'Триггер‑карточки', d:'Сделай 3 карточки: «Зачем беру телефон?», «Окна связи 11:30/16:30», «Срыв ≠ провал — 10 мин». Фото сюда.', type:'photo', pts:1},
      {k:'notifs', t:'Чистка уведомлений', d:'Отключи всё лишнее, оставь только важное.', type:'check', pts:1},
    ]},
    {id:3, tasks:[
      {k:'traffic', t:'Светофор приложений', d:'Разложи приложения: Зелён/Жёлт/Красн. Красные — на 3 экран/в папку «Намеренно». Скрин сюда.', type:'photo', pts:2},
      {k:'btnphone', t:'Режим кнопочного', d:'Grayscale, без виджетов, на главной только ключевые; лимиты 15–30 мин.', type:'check', pts:1},
    ]},
    {id:4, tasks:[
      {k:'buddy', t:'Бадди 2×2×2', d:'Договоритесь: 08:05, 14:05, 21:05. Нажмите «Напомнить».', type:'buddy', pts:1},
      {k:'3x25', t:'Фокус 3×25', d:'Три блока по 25 минут.', type:'check', pts:1},
    ]},
    {id:5, tasks:[
      {k:'wpDiet', t:'Обои «диеты»', d:'Фраза дня: «Сначала дело, потом лента».', type:'wallpaper', pts:1},
      {k:'limits', t:'Усиление лимитов', d:'Сократи экранное время ещё на 20–30%.', type:'check', pts:1},
    ]},
    {id:6, tasks:[
      {k:'quest4', t:'Офлайн‑квест 4 ч', d:'Выбери 4–6 миссий; 4 печати = +3 очка.', type:'quest', pts:3},
      {k:'ladderA', t:'Лестница времени', d:'Выбери 30 и 60 минут офлайн‑окон.', type:'ladder', pts:1},
    ]},
    {id:7, tasks:[
      {k:'ref', t:'Реферальный рывок 2+1', d:'Дай двум друзьям свой код и получи бонус.', type:'referral', pts:2},
      {k:'mini', t:'Мини‑награда', d:'Отпразднуй успехи недели.', type:'check', pts:1},
    ]},
    {id:8, tasks:[
      {k:'windows', t:'Окна связи', d:'Определи 2 окна (например, 11:30 и 16:30).', type:'check', pts:1},
      {k:'buddyPing', t:'Пинги бадди', d:'Включи напоминания о трёх касаниях.', type:'buddy', pts:1},
    ]},
    {id:9, tasks:[
      {k:'2x50', t:'2×50 минут', d:'Два глубоких блока по 50 минут.', type:'check', pts:1},
      {k:'store10', t:'Магазин (10 очков)', d:'Разбор 15 мин/эл.книга/промокод.', type:'store', pts:0},
    ]},
    {id:10, tasks:[
      {k:'sos', t:'Протокол Срыва‑90', d:'Стоп → Назови импульс → 4–7–8 ×4 → 10 мин мини‑задача.', type:'sos', pts:1},
    ]},
    {id:11, tasks:[
      {k:'audio', t:'Аудио‑доклад 60 сек', d:'В 21:00: «сделал/мешало/завтра» + фото телефона на зарядке вне спальни.', type:'voice', pts:1},
      {k:'noScreen', t:'Вечер без экрана', d:'Телефон вне спальни.', type:'check', pts:1},
    ]},
    {id:12, tasks:[
      {k:'env', t:'Оптимизация среды', d:'Организуй рабочее место. +очки.', type:'check', pts:2},
      {k:'store20', t:'Магазин (20 очков)', d:'Розыгрыш таймера/мерча.', type:'store', pts:0},
    ]},
    {id:13, tasks:[
      {k:'quest6', t:'Большой офлайн‑квест 6 ч', d:'4–6 миссий; 4 печати = +5 очков.', type:'quest', pts:5},
    ]},
    {id:14, tasks:[
      {k:'sum', t:'Итоги + бейджи', d:'Рефлексия, награды и приглашение друзей на следующий поток.', type:'summary', pts:2},
    ]},
  ];

  // === ХРАНИЛИЩЕ СОСТОЯНИЯ ===============================================
  const SKEY = 'detoxState_v1';
  function getState(){
    try{ return JSON.parse(localStorage.getItem(SKEY)) || {}; }catch(e){ return {}; }
  }
  function saveState(s){
    try{ localStorage.setItem(SKEY, JSON.stringify(s)); }catch(e){}
  }
  function todayISO(){ return new Date().toISOString().split('T')[0]; }
  function currentDayIndex(s){
    if(!s.startDate) return 0;
    const a = new Date(s.startDate), b = new Date();
    const ad = new Date(a.getFullYear(),a.getMonth(),a.getDate());
    const bd = new Date(b.getFullYear(),b.getMonth(),b.getDate());
    const diff = Math.floor((bd-ad)/86400000);
    return Math.min(Math.max(diff,0), DAYS.length-1);
  }

  // === UI УТИЛИТЫ ========================================================
  function h(tag, attrs={}, children=[]){
    const el = document.createElement(tag);
    for (const [k,v] of Object.entries(attrs)){
      if (k==='class') el.className=v;
      else if (k==='text') el.textContent=v;
      else if (k==='html') el.innerHTML=v;
      else el.setAttribute(k,v);
    }
    for(const c of children){ if (c) el.appendChild(c); }
    return el;
  }

  // === РЕНДЕР ============================================================
  function render(){
    let s = getState();
    if(!s.startDate){
      s = {startDate: todayISO(), tasksDone:{}, points:0, deposit:{amount:null, accepted:false, returned:false}};
      saveState(s);
    }
    const idx = currentDayIndex(s);
    const day = DAYS[idx];

    const app = document.getElementById('app'); app.innerHTML='';
    const top = document.getElementById('top'); top.innerHTML='';

    top.appendChild(h('div',{class:'card'},[
      h('div',{class:'kpi'},[
        h('span',{class:'pill',text:`День ${day.id} / ${DAYS.length}`}),
        h('span',{class:'pill',text:`Очки: ${s.points||0}`}),
        h('span',{class:'pill',text:`Депозит: ${s.deposit?.amount? (s.deposit.amount+' ₽'+(s.deposit.accepted?' ✓':'')):'—'}`})
      ]),
      h('div',{class:'row'},[
        btn('Старт 25 мин', ()=>startTimer(25)),
        btn('Старт 50 мин', ()=>startTimer(50)),
        btn('SOS‑90', openSOS),
        btn('Поставить обои', ()=>selectWallpaper(idx)),
        btn('Триггер‑карточки', ()=>promptPhoto('cards')),
        btn('Магазин очков', openStore),
        btn('Реферальный код', showReferral),
      ])
    ]));

    // список задач
    app.appendChild(h('div',{class:'grid'}, day.tasks.map(taskCard)));

    // подсказки дня
    app.appendChild(h('div',{class:'card'},[
      h('div',{class:'muted',text:'Подсказка дня'}),
      h('div',{text: dayTip(idx)})
    ]));
  }

  function taskCard(task){
    const s = getState();
    const done = !!(s.tasksDone?.[task.k]);
    const head = h('div',{},[
      h('h3',{text:task.t}), h('div',{class:'muted',text:`+${task.pts} оч.`})
    ]);
    const body = h('p',{text:task.d});
    const action = actionFor(task);
    const wrap = h('div',{class:'task'},[ h('div',{},[head,body, action]) ]);

    if(done){
      wrap.style.borderColor = 'rgba(46, 166, 255, .4)';
      wrap.appendChild(h('div',{class:'muted',text:'Выполнено ✓'}));
    }
    return wrap;
  }

  function btn(label, cb, cls='btn'){ const b=h('button',{class:cls, text:label}); b.onclick=cb; return b; }

  function markDone(key, pts){
    const s = getState();
    if(!s.tasksDone) s.tasksDone={};
    if(!s.tasksDone[key]){
      s.tasksDone[key]=true;
      s.points=(s.points||0)+(pts||0);
      saveState(s);
    }
    render();
  }

  function actionFor(task){
    switch(task.type){
      case 'deposit': {
        const s = getState();
        const box = h('div');
        const input = h('input',{type:'number',placeholder:'Сумма 500–2000 ₽',min:'500',max:'2000',style:'width:160px;padding:8px;border-radius:8px;background:#101114;color:#fff;border:1px solid #2b2d31;margin-right:8px'});
        const sign = btn(s.deposit?.accepted?'Подписано':'Подписать договор', ()=>{
          const val = parseInt(input.value||'0',10);
          if (!val || val<500 || val>2000){ alert('Введите сумму от 500 до 2000 ₽'); return; }
          const st=getState();
          st.deposit={amount:val, accepted:true, returned:false};
          saveState(st);
          markDone(task.k, task.pts);
        });
        box.append(input, sign);
        return box;
      }
      case 'wallpaper': {
        return btn('Отметить установку обоев', ()=>{
          alert('Поставьте обои‑напоминание на экран блокировки и пришлите фото в чат боту.'); 
          markDone(task.k, task.pts);
        }, 'btn secondary');
      }
      case 'photo': {
        return btn('Загрузил(а) фото', ()=>{
          alert('Прикрепите скрин/фото в чат с ботом.');
          markDone(task.k, task.pts);
        }, 'btn secondary');
      }
      case 'check': {
        return btn('Готово', ()=>markDone(task.k, task.pts), 'btn secondary');
      }
      case 'buddy': {
        return btn('Назначить напоминания', ()=>{
          alert('Назначьте 08:05 / 14:05 / 21:05. Бот пришлёт пинг вам и бадди.');
          markDone(task.k, task.pts);
        }, 'btn secondary');
      }
      case 'quest': {
        return btn('Выбрать миссии', ()=>{
          const ok = confirm('Выберите 4–6 миссий и действуйте офлайн 4–6 часов. Поставьте печати в трекере. Отметить как выполнено?');
          if(ok) markDone(task.k, task.pts);
        }, 'btn secondary');
      }
      case 'ladder': {
        return btn('Выбрать ступень', ()=>{
          alert('Неделя 1: 30 и 60 мин. Неделя 2: 120 и 240–360 мин. Бот добавит 2 офлайн‑окна в календарь (при серверной интеграции).');
          markDone(task.k, task.pts);
        }, 'btn secondary');
      }
      case 'referral': {
        return btn('Показать код', ()=>{ showReferral(); markDone(task.k, task.pts); }, 'btn secondary');
      }
      case 'store': {
        return btn('Открыть магазин', ()=>{ openStore(); }, 'btn secondary');
      }
      case 'sos': {
        return btn('Запустить SOS‑90', ()=>{ openSOS(); markDone(task.k, task.pts); });
      }
      case 'voice': {
        return btn('Записать 60 сек', ()=>{
          alert('В 21:00 запишите голос: «что сделал/мешало/завтра». Бот сохранит аудио (при серверной части).');
          markDone(task.k, task.pts);
        }, 'btn secondary');
      }
      case 'summary': {
        return btn('Подвести итоги', ()=>{
          alert('Итоги: что сработало, метрики экрана, какие привычки оставить. Бот выдаст бейджи и награды.');
          markDone(task.k, task.pts);
        });
      }
      default: return h('span',{class:'muted',text:'—'});
    }
  }

  // === МАЛЫЕ ФУНКЦИИ =====================================================
  function dayTip(i){
    const arr = [
      'Сегодня — базовая настройка и старт очков.',
      'Закрепляем намерение карточками и чистим шум.',
      'Уменьшаем триггеры на главном экране.',
      'Поддержка бадди = стабильность.',
      'Экран — только после дела.',
      'Первые длинные офлайн‑окна.',
      'Поддержим инерцию, делимся с друзьями.',
      'Окна связи снижают микропереключения.',
      'Два глубоких фокуса вместо десятка мелких.',
      'Планы срываются — это норм. SOS‑90 поможет.',
      'Голосовой отчёт быстрее и живее.',
      'Дотюним среду, чтобы помогала.',
      'Большой офлайн‑квест — босс‑левел.',
      'Финишируем и награждаем!'
    ];
    return arr[i] || '';
  }

  function selectWallpaper(dayIndex){
    const phrase = WALLPAPERS[Math.min(dayIndex, WALLPAPERS.length-1)];
    alert('Фраза для обоев: '+phrase+'\n\nСоберите простой фон с крупным текстом и поставьте на экран блокировки. Пришлите фото в чат боту.');
  }

  function openSOS(){
    // 90 секунд: стоп → назвать импульс → дыхание 4‑7‑8 ×4; затем 10 минут
    const step1 = confirm('Срыв? Шаг 1: Стоп. Назовите импульс вслух.\nНажмите OK — начнём дыхание 4‑7‑8 ×4 цикла.');
    if(!step1) return;
    let cycles = 4;
    (function breath(){
      if(cycles<=0){ startTimer(10, '10‑мин мини‑сессия'); return; }
      alert('Дышим 4‑7‑8: вдох 4с → задержка 7с → выдох 8с.\nЦикл '+(5-cycles)+' из 4');
      cycles--; breath();
    })();
  }

  function openStore(){
    const s = getState();
    const pts = s.points||0;
    let msg = 'У тебя '+pts+' очков.\n\nДоступно:\n- 10 очков: разбор 15 мин / e‑book / промокод партнёра\n- 20 очков: розыгрыш таймера/мерча\n- 30 очков: вход в следующий мини‑поток\n';
    alert(msg);
  }

  function showReferral(){
    const code = (getState().refCode) || ('R'+Math.random().toString(36).slice(2,8).toUpperCase());
    const s = getState(); s.refCode = code; saveState(s);
    alert('Твой код: '+code+'\nДай двум друзьям — получишь бонус (после верификации на сервере).');
  }

  function startTimer(mins, label){
    const ms = Math.max(1, Math.floor(mins)) * 60 * 1000;
    const end = Date.now() + ms;
    const tick = ()=>{
      const left = end - Date.now();
      if(left<=0){ alert((label||'Таймер')+' завершён!'); return; }
      const m = Math.floor(left/60000), s = Math.floor((left%60000)/1000);
      document.title = (label||'Фокус')+': '+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');
      requestAnimationFrame(tick);
    };
    tick();
  }

  // init
  render();
})();